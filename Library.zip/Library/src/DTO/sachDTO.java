/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import java.util.Date;

/**
 *
 * @author DO THE TUNG
 */
public class sachDTO {
    
    public int Ma;
    public String Ten;
     public int MaTacGia;
     public   int MaTheLoai;
     public int MaNhaSanXuat;
     public int NamSanXuat;
      public int soLuong;
      public String Anh;
      public int Gia;

    public sachDTO(int Ma, String Ten, int MaTacGia, int MaTheLoai, int MaNhaSanXuat, int NamSanXuat, int soLuong, String Anh, int Gia) {
        this.Ma = Ma;
        this.Ten = Ten;
        this.MaTacGia = MaTacGia;
        this.MaTheLoai = MaTheLoai;
        this.MaNhaSanXuat = MaNhaSanXuat;
        this.NamSanXuat = NamSanXuat;
        this.soLuong = soLuong;
        this.Anh = Anh;
        this.Gia = Gia;
    }
    public sachDTO()
    {
        
    }

    public int getMa() {
        return Ma;
    }

    public void setMa(int Ma) {
        this.Ma = Ma;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public int getMaTacGia() {
        return MaTacGia;
    }

    public void setMaTacGia(int MaTacGia) {
        this.MaTacGia = MaTacGia;
    }

    public int getMaTheLoai() {
        return MaTheLoai;
    }

    public void setMaTheLoai(int MaTheLoai) {
        this.MaTheLoai = MaTheLoai;
    }

    public int getMaNhaSanXuat() {
        return MaNhaSanXuat;
    }

    public void setMaNhaSanXuat(int MaNhaSanXuat) {
        this.MaNhaSanXuat = MaNhaSanXuat;
    }

    public int getNamSanXuat() {
        return NamSanXuat;
    }

    public void setNamSanXuat(int NamSanXuat) {
        this.NamSanXuat = NamSanXuat;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getAnh() {
        return Anh;
    }

    public void setAnh(String Anh) {
        this.Anh = Anh;
    }

    public int getGia() {
        return Gia;
    }

    public void setGia(int Gia) {
        this.Gia = Gia;
    }
    
    
      
}
