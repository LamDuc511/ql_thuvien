/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author quang
 */
public class PhieuPhatDTO {
    private String ngayViPham, soTienPhat;
    private int maSach,maPhieuMuon,maViPham,ma;

    public int getMa() {
        return ma;
    }

    public void setMa(int ma) {
        this.ma = ma;
    }

    public String getNgayViPham() {
        return ngayViPham;
    }

    public void setNgayViPham(String ngayViPham) {
        this.ngayViPham = ngayViPham;
    }

    public String getSoTienPhat() {
        return soTienPhat;
    }

    public void setSoTienPhat(String soTienPhat) {
        this.soTienPhat = soTienPhat;
    }

    public int getMaSach() {
        return maSach;
    }

    public void setMaSach(int maSach) {
        this.maSach = maSach;
    }

    public int getMaPhieuMuon() {
        return maPhieuMuon;
    }

    public void setMaPhieuMuon(int maPhieuMuon) {
        this.maPhieuMuon = maPhieuMuon;
    }

    public int getMaViPham() {
        return maViPham;
    }

    public void setMaViPham(int maViPham) {
        this.maViPham = maViPham;
    }
}
